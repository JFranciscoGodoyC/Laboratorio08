#Actividad03
#Parte01
print("Francisco Godoy - 1245724")
n1 = float(input("Ingrese una cantidad en metros:  "))
print("Resultado")
#Operaciones01
kilometros = n1/1000
millas = (n1/1000)/1.60934
pies = n1*3.28084
pulgadas = pies*12
#Representación01
print("Millas : ",round(millas,2))
print("Kilómetros : ",round(kilometros,2))
print("Pies : ",round(pies,2))
print("Pulgadas : ",round(pulgadas,2))

#Parte02
print()
print("Francisco Godoy - 1245724")
n2 = float(input("Ingrese otra cantidad en metros:  "))
print("Resultado")
#Operaciones02
yardas = n2*1.09361
pies1 = n2*3.28084
pulgadas1 = pies1*12
#Representación02
print("Yardas : ",round(yardas,2))
print("Pies : ", round(pies1,2))
print("Pulgadas : ",round(pulgadas1,2))