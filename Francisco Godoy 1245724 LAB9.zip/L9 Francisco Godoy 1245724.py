#Actividad02
#Parte01
print("Ejercicio 1: Operaciones aritméticas")
n1 =int(input("Ingrese un valor entero:  "))
n2 = int(input("Ingrese otro valor entero:  "))
#Operaciones01
Total = n1+n2
Diferencia = n1-n2
Producto = n1*n2
Cocientereal = n1/n2
Cocienteentero = n1//n2
Cocientemodular = n1%n2
Potencia = n1**n2
#Representación01
print(n1,"+",n2,"=",Total)
print(n1,"-",n2,"=",Diferencia)
print(n1,"*",n2,"=",Producto)
print(n1,"/",n2,"=",Cocientereal)
print(n1,"//",n2,"=",Cocienteentero)
print(n1,"%",n2,"=",Cocientemodular)
print(n1,"^",n2,"=",Potencia)

#Parte02
print()
print("Ejercicio 2: Operaciones booleanas")
#Operaciones01
Igualdad = n1==n2
Mayorque = n1>n2
Menorque = n1<n2
Distinto = n1!=n2
#Representación02
print(n1,"es igual a",n2,"=",Igualdad)
print(n1,"es mayor que",n2,"=",Mayorque)
print(n1,"es menor que",n2,"=",Menorque)
print(n1,"es distindo a",n2,"=",Distinto)

#Parte03
print()
print("Ejercicio 3: jerarquía de operadores")
x1 = int(input("Ingrese un valor entero:  "))
x2 = int(input("Ingrese un valor entero:  "))
x3 = int(input("Ingrese un valor entero:  "))
#Operaciones03
ecu1 = x1*x2+x3
ecu2 = x1*(x2+x3)
ecu3 = x1/(x2+x3)
ecu4 = ((3*x1)+(2*x2))/(x3**2)
#Representación02
print("a*b+c",ecu1)
print("a(b+c)",ecu2)
print("a/(b+c)",ecu3)
print("(3a+2b)/(c^2)",ecu4)