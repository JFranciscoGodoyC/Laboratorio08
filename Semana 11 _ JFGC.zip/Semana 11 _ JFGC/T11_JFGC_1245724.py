n=0
n1=0
print("José Francisco Godoy Castellanos - 1245724")
print("Semana No. 11: Ejercicio 2")
while n<=0:
    print("Ingrese un número: ")
    n = int(input())
    print()
    if n<=0:
        print("El número ingresado debe ser mayor que cero")
        print()

A=1; A1=1
B=1; B1=1
i=1; i1=1
resultado = ("(1/"+str(A)+")")
resultado2 = ("(1/2^"+ str(A1)+")")

if n>1:
    print("Parte 1")
    while i<n:
        B=B+1
        resultado+=(" + (1/"+ str(B)+")")
        i =i+1
    print(resultado)
    print()
    print("Parte 2")
    while i1<n:
        B1=B1+1
        resultado2+=(" + (1/2^"+ str(B1)+")")
        i1=i1+1
    print(resultado2)
else:
    print("Parte 1")
    print(resultado)
    print()
    print("Parte 2")
    print(resultado2)

k=0
x=0
a=0
n1=0
print()
while x<=0 or a<=0 or n1<=0:
    print("Parte 3")
    print("Sumatoria de números: ")
    print("Ingrese el valor de 'x' para la sumatoria: ")
    x = int(input())
    print("Ingrese el valor de 'a' para la sumatoria: ")
    a = int(input())
    print("Ingrese el valor de 'n' para la sumatoria: ")
    n1 = int(input())
    if x<=0 or a<=0 or n1<=0:
        print("El número ingresado debe ser mayor que cero")
        print()

if x>0 or a>0 or n1>0:
    if k==0:
        print('[(',x,'^'+ str(k)+ ')(', a,'^(', n1, '-'+ str(k)+ '))]')
        while k<n1:
            k=k+1
            print(' + [(',x,'^'+ str(k)+ ')(', a,'^(', n1, '-'+ str(k)+ '))]')
            