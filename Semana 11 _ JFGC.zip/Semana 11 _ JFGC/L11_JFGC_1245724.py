n = 0
print("Semana No. 11: Ejercicio 1")
while n<=0:
    print("Ingrese un número: ")
    n = int(input())
    if n<=0:
        print("El número ingresado debe ser mayor que cero")
        print()
A=0
B=1
C=0
i=2
resultado = str(A)
if n >1:
    resultado+=(", "+ str(B))
    while i<n:
        C=A+B
        resultado+=(", "+ str(C))
        A=B
        A=C
        i = i + 1
    print(resultado)
else:
    print(resultado)
